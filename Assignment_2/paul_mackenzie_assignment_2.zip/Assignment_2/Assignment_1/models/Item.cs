﻿//Mackenzie Paul
//Assignment 2 (Modified from Assignment 1)
//Due 06/15/21

using System;
using System.Collections.Generic;

namespace Assignment_2.models
{
    public class Item
    {
        private string name;
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        private string description;
        public string Description
        {
            get
            {
                return description;
            }
            set
            {
                description = value;
            }
        }

        private bool isDeleted;
        public bool IsDeleted
        {
            get
            {
                return isDeleted;
            }
            set
            {
                isDeleted = value;
            }
        }

        bool isTask;
        public bool IsTask
        {
            get
            {
                return isTask;
            }
            set
            {
                isTask = value;
            }
        }

        public virtual DateTime Deadline { get; set; }
        public virtual bool IsComplete { get; set; }
        public virtual DateTime Start { get; set; }
        public virtual DateTime Stop { get; set; }
        public virtual List<string> Attendees { get; set; }

        public Item(string name, string description, bool isDeleted, bool isTask)
        {
            this.Name = name;
            this.Description = description;
            this.IsDeleted = isDeleted;
            this.IsTask = isTask;
        }

        public virtual string ToString(bool forTask)
        {
            if (forTask)
            {
                return $"{Name} - {Description} \n\t";
            }
            return ToString();
        }
        
    }
}
