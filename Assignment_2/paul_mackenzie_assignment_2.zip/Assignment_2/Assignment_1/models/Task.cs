﻿//Mackenzie Paul
//Assignment 2 (Modified from Assignment 1)
//Due 06/15/21

using System;
using System.Collections.Generic;

namespace Assignment_2.models
{

    public class Task : Item
    {


        //deadline
        DateTime deadline;
        public override DateTime Deadline
        {
            get
            {
                return deadline;
            }
            set
            {
                deadline = value;
            }
        }

        //isComplete
        bool isComplete;
        public override bool IsComplete
        {
            get
            {
                return isComplete;
            }
            set
            {
                isComplete = value;
            }
        }

      

        public Task(string name, string description, DateTime deadline,
            bool isComplete, bool isDeleted)
            :base(name, description, isDeleted, true) {
            
            this.Deadline = deadline;
            this.IsComplete = isComplete;
        }

        public override string ToString(bool v)
        {
            
            var task_info = "Task\n" + Name + " - " + Description + "\n\tDeadline: "
                + Deadline.ToString("MMM dd, yyyy") + "\n";

            

            return task_info;
        }
    }
}
