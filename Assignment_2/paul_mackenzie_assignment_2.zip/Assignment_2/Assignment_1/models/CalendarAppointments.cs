﻿//Mackenzie Paul
//Assignment 2 (Modified from Assignment 1)
//Due 06/15/21

using System;
using System.Collections.Generic;

namespace Assignment_2.models
{
    public class CalendarAppointments : Item
    {
       

        private DateTime start;
        public override DateTime Start { get
            {
                return start;
            }
            set
            {
                start = value;
            }
        }
        private DateTime stop;
        public override DateTime Stop
        {
            get
            {
                return stop;
            }
            set
            {
                stop = value;
            }
        }

        private List<string> attendees;
        public override List<string> Attendees
        {
            get
            {
                return attendees;
            }

            set
            {
                attendees = value;
            }
        }

        public CalendarAppointments(string name, string description,
            DateTime start, DateTime stop, List<string> attendees, bool isDeleted)
            : base(name, description, isDeleted, false)
        {
            this.Start = start;
            this.Stop = stop;
            this.Attendees = attendees;
                
        }

        public override string ToString(bool v)
        {

            var task_info = $"Appointment\n{Name} - {Description} \n\t Start Date: {Start.ToString("MMM dd, yyyy")}\n" +
                $"\t End Date: {Stop.ToString("MMM dd, yyyy")}\nAttendees:\n";
            //print out list of attendees
            foreach (var attendee in Attendees)
            {
                task_info += attendee + "\n";
            }

            return task_info;
        }
    }
}
    

