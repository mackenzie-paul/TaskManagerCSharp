﻿//Mackenzie Paul
//Assignment 2 (Modified from Assignment 1)
//Due 06/15/21
//referenced assignment 2 files on Canvas

using System;
using System.Collections.Generic;
using System.Linq;
using Assignment_2.models;


namespace Assignment_2
{
    class Program
    {

        static void Main(string[] args)
        {
            bool exit = false;

            //list stores all of our tasks
            List<Item> task_list = new List<Item>();
            ListNavigator<Item> taskNavigator = new ListNavigator<Item>(task_list);

            //while loop that handles user interaction with tasks
            while (!exit)
            {
                //menu
                Console.WriteLine("\n");
                Console.WriteLine("1. Create Task");
                Console.WriteLine("2. List All Tasks");
                Console.WriteLine("3. Delete Task");
                Console.WriteLine("4. Edit Task");
                Console.WriteLine("5. Complete Task");
                Console.WriteLine("6. List Outstanding Tasks");
                Console.WriteLine("7: Search for Task");
                Console.WriteLine("8. Exit");
                Console.WriteLine("\n");
                Console.WriteLine("Please select option: ");

                //user choice
                var choice = Console.ReadLine();
                Console.WriteLine("\n");

                if (int.TryParse(choice, out int intChoice))
                {

                    switch (intChoice)
                    {
                        /**************/
                        //1. Creating Task
                        case 1:
                            Console.WriteLine("Would you like to create an appointment?(y or n)");
                            bool valid_input = false;
                            while (!valid_input)
                            {
                                var appt = Console.ReadLine();
                                if (appt.Equals("n", StringComparison.InvariantCultureIgnoreCase))
                                {
                                    Console.WriteLine("Creating Task...");
                                    Console.WriteLine("Please enter task name: ");
                                    var name = Console.ReadLine();
                                    Console.WriteLine("Please enter task description: ");
                                    var description = Console.ReadLine();

                                    Console.WriteLine("Please enter task deadline (mm/dd/yy): ");
                                    var deadline = Console.ReadLine();
                                    var parseDeadline = DateTime.Parse(deadline);

                                    //creating task and adding it to task_list
                                    Task task = new Task(name, description, parseDeadline, false, false);
                                    task_list.Add(task);


                                }
                                //creates appointment
                                else if (appt.Equals("y", StringComparison.InvariantCultureIgnoreCase))
                                {
                                    Console.WriteLine("Creating Appointment...");
                                    Console.WriteLine("Please enter Appointment Name: ");
                                    var appt_name = Console.ReadLine();

                                    Console.WriteLine("Please enter appointment description: ");
                                    var appt_description = Console.ReadLine();

                                    Console.WriteLine("Please enter appointment start date (mm/dd/yy): ");
                                    var appt_start = Console.ReadLine();
                                    var parsedApptStart = DateTime.Parse(appt_start);

                                    Console.WriteLine("Please enter appointment end date (mm/dd/yy): ");
                                    var appt_stop = Console.ReadLine();
                                    var parsedApptStop = DateTime.Parse(appt_stop);


                                    Console.WriteLine("Please enter list of attendees (x to exit): ");

                                    bool still_attendees = true;
                                    List<string> attendees = new List<string>();
                                    while (still_attendees)
                                    {
                                        var appt_attendee = Console.ReadLine();
                                        if (appt_attendee.Equals("x"))
                                        {
                                            still_attendees = false;
                                        }
                                        else
                                        {
                                            attendees.Add(appt_attendee);
                                        }
                                        
                                    }
                                    CalendarAppointments new_cal_appt =
                                        new CalendarAppointments(appt_name,
                                        appt_description, parsedApptStart, parsedApptStop, attendees, false);
                                    task_list.Add(new_cal_appt);
                                }
                                else
                                {
                                    Console.WriteLine("Invalid Input");
                                }
                                valid_input = true;
                            }

                            
                            break;
                        /**************/
                        //2. Listing Tasks

                        case 2:
                            Console.WriteLine("Listing all tasks...");
                            Console.WriteLine("\n");

                            var page = taskNavigator.GetCurrentPage();
                            bool stillPaging = true;


                            while (stillPaging)
                            {
                                foreach (var t in page)
                                {

                                    Console.WriteLine(t.Value.ToString(true));

                                }
                                if (taskNavigator.HasPreviousPage)
                                {
                                    Console.WriteLine("p. Previous Page");
                                }
                                if (taskNavigator.HasNextPage)
                                {
                                    Console.WriteLine("n. Next Page");
                                }
                                Console.WriteLine("x. Return to Main Menu");

                                var input = Console.ReadLine();
                                if (input.Equals("n", StringComparison.InvariantCultureIgnoreCase))
                                {
                                    page = taskNavigator.GoForward();
                                }
                                else if (input.Equals("p", StringComparison.InvariantCultureIgnoreCase))
                                {
                                    page = taskNavigator.GoBackward();
                                }
                                else if (input.Equals("x", StringComparison.InvariantCultureIgnoreCase))
                                {
                                    stillPaging = false;
                                }
                            }



                            break;
                        ///**************/
                        ////3. Deleting Task
                        case 3:
                            Console.WriteLine("Deleting Task...");
                            Console.WriteLine("Enter Task Name: ");
                            bool delete_task_found = false;
                            while (!delete_task_found)
                            {
                                string task_name_entry = Console.ReadLine();
                                for (int i = 0; i < task_list.Count; i++)
                                {
                                    if (task_name_entry.Equals(task_list[i].Name)
                                        && !task_list[i].IsDeleted)
                                    {
                                        Console.WriteLine("Task Found");
                                        Console.WriteLine("Task Deleted");
                                        task_list[i].IsDeleted = true;
                                        task_list.RemoveAt(i);
                                        delete_task_found = true;
                                    }
                                }
                                if (!delete_task_found)
                                {
                                    Console.WriteLine("Task Not Found. Please try again.");
                                }
                            }
                            taskNavigator = new ListNavigator<Item>(task_list);
                            break;
                        ///*************/
                        ////4. Editing Task
                        case 4:
                            bool task_changed = true;
                            bool task_found = false;
                            
                            int id = -1;
                            Console.WriteLine("Editing Task...");

                            //get task name to change
                            Console.WriteLine("Enter task/appointment name: ");
                            while (!task_found)
                            {
                                string task_name_entry = Console.ReadLine();
                                for (int i = 0; i < task_list.Count; i++)
                                {
                                    if (task_name_entry.Equals(task_list[i].Name)
                                        && !task_list[i].IsDeleted)
                                    {
                                        Console.WriteLine("\n");
                                        task_found = true;
                                        task_changed = false;
                                        id = i;
                                    }
                                }
                                if (!task_found)
                                {
                                    Console.WriteLine("Task Not Found. Please try again.");
                                }
                            }


                            while (!task_changed)
                            {
                                //EDITING A TASK
                                if (task_list[id].IsTask)
                                {
                                    //item-to-change menu
                                    Console.WriteLine("Select value you would like to change.");
                                    Console.WriteLine("1. Task Name");
                                    Console.WriteLine("2. Task Description");
                                    Console.WriteLine("3. Task Deadline");
                                    Console.WriteLine("4. Return to Main Menu");

                                    var edit_choice = Console.ReadLine();
                                    if (int.TryParse(edit_choice, out int edit_choice_val))
                                    {
                                        switch (edit_choice_val)
                                        {
                                            case 1:
                                                Console.WriteLine("Editing name...");
                                                Console.WriteLine("Enter New Name: ");
                                                var new_name = Console.ReadLine();
                                                task_list[id].Name = new_name;
                                                break;
                                            case 2:
                                                Console.WriteLine("Editing Description...");
                                                var new_description = Console.ReadLine();
                                                task_list[id].Description = new_description;
                                                break;
                                            case 3:
                                                Console.WriteLine("Enter New Deadline (mm/dd/yy):");
                                                var new_deadline = Console.ReadLine();
                                                var newParseDeadline = DateTime.Parse(new_deadline);
                                                task_list[id].Deadline = newParseDeadline;
                                                break;
                                            case 4:
                                                Console.WriteLine("Returning to Main Menu...");
                                                task_changed = true;
                                                break;
                                        }
                                    }
                                }
                                else

                                {
                                    //EDITING AN APPOINTMENT
                                    Console.WriteLine("Select value you would like to change.");
                                    Console.WriteLine("1. Appointment Name");
                                    Console.WriteLine("2. Appointment Description");
                                    Console.WriteLine("3. Appointment Start Date");
                                    Console.WriteLine("4. Appointment End Date");
                                    Console.WriteLine("5. Add Attendee");
                                    Console.WriteLine("6. Return to Main Menu");

                                    var edit_choice = Console.ReadLine();
                                    if (int.TryParse(edit_choice, out int edit_choice_val))
                                    {
                                        switch (edit_choice_val)
                                        {
                                            case 1:
                                                Console.WriteLine("Enter New Name: ");
                                                var new_name = Console.ReadLine();
                                                task_list[id].Name = new_name;
                                                break;
                                            case 2:
                                                Console.WriteLine("Enter New Description: ");
                                                var new_description = Console.ReadLine();
                                                task_list[id].Description = new_description;
                                                break;
                                            case 3:
                                                Console.WriteLine("Enter New Start Date (mm/dd/yy):");
                                                var new_startDate = Console.ReadLine();
                                                var newParseStartDate = DateTime.Parse(new_startDate);
                                                task_list[id].Start = newParseStartDate;
                                                break;
                                            case 4:
                                                Console.WriteLine("Enter New Stop Date (mm/dd/yy):");
                                                var new_stopDate = Console.ReadLine();
                                                var newParseStopDate = DateTime.Parse(new_stopDate);
                                                task_list[id].Stop = newParseStopDate;
                                                break;
                                            case 5:
                                                Console.WriteLine("Enter New Attendee: ");
                                                var new_attendee = Console.ReadLine();
                                                task_list[id].Attendees.Add(new_attendee);
                                                break;
                                            case 6:        
                                                task_changed = true;
                                                break;
                                        }
                                    }
                                }
                            }
                            break;
                        ///*****************/
                        ////Completeing Task
                        case 5:
                            Console.WriteLine("Completing Task...");
                            bool new_task_found = false;

                            
                            while (!new_task_found)
                            {
                                Console.WriteLine("Enter task name (or x to exit): ");
                                string task_name_entry = Console.ReadLine();

                                switch (task_name_entry)
                                {
                                    case "x":
                                        new_task_found = true;
                                        break;
                                    default:
                                        for (int i = 0; i < task_list.Count; i++)
                                        {
                                            if (task_name_entry.Equals(task_list[i].Name)
                                                && !task_list[i].IsDeleted && task_list[i].IsTask)
                                            {
                                                //if task not completed yet
                                                if (!task_list[i].IsComplete)
                                                {
                                                    Console.WriteLine("Task Completed");
                                                    new_task_found = true;
                                                    task_list[i].IsComplete = true;
                                                }
                                                //task already completed
                                                else
                                                {
                                                    Console.WriteLine("Task Already Complete");
                                                }
                                            }
                                        }
                                        //no task found
                                        if (!new_task_found)
                                        {
                                            Console.WriteLine("Task not found. Please try again.");
                                        }
                                        break;
                                }

                            }
                            

                            break;
                        ///**************************/
                        ////Listing Outstanding Tasks
                        case 6:
                            Console.WriteLine("Outstanding Tasks");
                            Console.WriteLine("\n");
                            List<Item> incomplete_tasks = new List<Item>();

                            //creating separate list of incomplete tasks
                            for (int i = 0; i < task_list.Count; i++)
                            {
                                if (!task_list[i].IsComplete && !task_list[i].IsDeleted
                                    && task_list[i].IsTask)
                                {
                                    incomplete_tasks.Add(task_list[i]);
                                }
                            }

                            ListNavigator<Item> incompleteNavigator =
                                new ListNavigator<Item>(incomplete_tasks);
                            var o_page = incompleteNavigator.GetCurrentPage();
                            bool o_stillPaging = true;


                            while (o_stillPaging)
                            {
                                foreach (var t in o_page)
                                {

                                    Console.WriteLine(t.Value.ToString(true));
                                }
                                if (incompleteNavigator.HasPreviousPage)
                                {
                                    Console.WriteLine("p. Previous Page");
                                }
                                if (incompleteNavigator.HasNextPage)
                                {
                                    Console.WriteLine("n. Next Page");
                                }
                                Console.WriteLine("x. Return to Main Menu");

                                var input = Console.ReadLine();
                                if (input.Equals("n", StringComparison.InvariantCultureIgnoreCase))
                                {
                                    o_page = incompleteNavigator.GoForward();
                                }
                                else if (input.Equals("p", StringComparison.InvariantCultureIgnoreCase))
                                {
                                    o_page = incompleteNavigator.GoBackward();
                                }
                                else if (input.Equals("x", StringComparison.InvariantCultureIgnoreCase))
                                {
                                    o_stillPaging = false;
                                }
                            }


                            break;
                        ///****************/
                        //Search for Task
                        case 7:
                            Console.WriteLine("Search for Task");
                            Console.WriteLine("Enter key word(s): ");
                            var search_string = Console.ReadLine();
                            //using LINQ to find task/appointment that matches user input
                            var task_item =
                                from task in task_list
                                where task.IsTask == true && (
                                task.Name.Contains(search_string) ||
                                task.Description.Contains(search_string) )
                                select task;
                            var appt_item =
                                from task in task_list
                                where task.IsTask == false && (
                                task.Name.Contains(search_string) ||
                                task.Description.Contains(search_string) ||
                                task.Attendees.Contains(search_string))
                                select task;
                            Console.WriteLine("\n");

                            //iterate through results
                            foreach (var task in task_item)
                            {
                                Console.WriteLine(task.ToString(true));
                            }
                            foreach (var task in appt_item)
                            {
                                Console.WriteLine(task.ToString(true));
                            }
                            break;

                        /****************/
                        //Exiting Program
                        case 8:
                            Console.WriteLine("Exiting Program.");
                            exit = true;
                            break;
                    }
                }
            }
        }
    }
}
