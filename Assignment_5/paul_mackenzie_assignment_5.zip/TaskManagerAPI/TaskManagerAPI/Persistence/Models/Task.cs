﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace TaskManagerAPI.Persistence.Models
{
    [Table("dbo.Task")]
    public class Task
    {
        
        
    }
}
