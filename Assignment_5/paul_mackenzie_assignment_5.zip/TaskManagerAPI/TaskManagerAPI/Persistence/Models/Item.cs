﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TaskManagerAPI.Persistence.Models
{
    [Table("dbo.Item")]
    public class Item
    {
        
    }
}
