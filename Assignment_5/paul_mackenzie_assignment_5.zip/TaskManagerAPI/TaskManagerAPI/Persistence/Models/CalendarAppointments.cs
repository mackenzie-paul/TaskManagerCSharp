﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace TaskManagerAPI.Persistence.Models
{
    [Table("dbo.CalendarAppointments")]
    public class CalendarAppointments
    {
        public CalendarAppointments()
        {
        }
    }
}
