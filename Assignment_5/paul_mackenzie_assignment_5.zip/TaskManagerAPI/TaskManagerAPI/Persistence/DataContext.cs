﻿using System;
using System.Collections.Generic;
using Library.TaskManager;
using MongoDB.Bson;
using MongoDB.Driver;
using System.Data.Entity;

namespace TaskManagerAPI
{
    public class DataContext:DbContext
    {
        public static List<Item> Task_List = new List<Item> {};

        public DataContext() : base("Server=;Database=TASK_MANAGER_DB;Trusted_Connection=True")
        {
            Configuration.ProxyCreationEnabled = false;
        }

        public virtual DbSet<Item> Items { get; set; }
        public virtual DbSet<Task> Tasks { get; set; }
        public virtual DbSet<CalendarAppointments> Appts { get; set; }

    }
}
