﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Library.TaskManager;
using MongoDB.Bson;
using MongoDB.Driver;

namespace TaskManagerAPI.Controllers.EC
{
    public class TaskEC
    {
        public List<Item> Get()
        {
            
            
            var results = new List<Item>();
            var dbClient = new MongoClient("mongodb://127.0.0.1:27017");
            var db = dbClient.GetDatabase("TASK_MANAGER_DB");
            var collection = db.GetCollection<BsonDocument>("items");
            
            var cursor = collection.Find(new BsonDocument()).ToCursor();
            foreach (var doc in cursor.ToList())
            {
                
                var id = (Guid)doc[1];
                var filter = Builders<BsonDocument>.Filter.Eq("id", id);

                var next_collection = db.GetCollection<BsonDocument>("tasks");
                var next_cursor = next_collection.Find(filter).ToCursor();
                var next_doc = next_cursor.ToList();
                var next_count = next_collection.CountDocuments(filter);

                var cal_collection = db.GetCollection<BsonDocument>("calendar_appts"); 
                var cal_count = cal_collection.CountDocuments(filter);
                
                if(next_count != 0)
                {
                    

                    Library.TaskManager.Task task = new Library.TaskManager.Task(
                        (string)doc[2], (string)doc[3], (DateTime)next_doc[0][2],
                        (bool)next_doc[0][3], (bool)doc[5], (string)doc[6]);
                    task.Id = id;
                    results.Add(task);
                }
                else if(cal_count != 0) 
                {
                    //query calendar appointments and find this value
                    
                    next_collection = db.GetCollection<BsonDocument>("calendar_appts");
                    next_cursor = next_collection.Find(filter).ToCursor();
                    
                    next_doc = next_cursor.ToList();

                    string attendee_string = (string)next_doc[0][4];
                    string[] attendees_array = attendee_string.Split(',');
                    List<string> attendees = attendees_array.ToList();

                    CalendarAppointments appt = new CalendarAppointments(
                        (string)doc[2], (string)doc[3], (DateTime)next_doc[0][2],
                        (DateTime)next_doc[0][2], attendees,
                        (bool)doc[5], (string)doc[6]);
                    appt.Id = id;
                    results.Add(appt);
                }
            }
            
            return results;
        }

        public List<Library.TaskManager.Task> GetTasksAsync()
        {
            
            List<Library.TaskManager.Task> temp = new List<Library.TaskManager.Task>();

            //connect to database and tasks and items tables
            var dbClient = new MongoClient("mongodb://127.0.0.1:27017");
            var db = dbClient.GetDatabase("TASK_MANAGER_DB");
            var collection = db.GetCollection<BsonDocument>("tasks");
            var item_collection = db.GetCollection<BsonDocument>("items");

            var cursor = collection.Find(new BsonDocument()).ToCursor();
            var count = collection.CountDocuments(new BsonDocument());
            if (count != 0)
            {
                foreach (var doc in cursor.ToList())
                {

                    var id = (Guid)doc[1];
                    
                    var filter = Builders<BsonDocument>.Filter.Eq("id", id);
                    var item_cursor = item_collection.Find(filter).ToCursor();
                    var item_doc = item_cursor.ToList();

                   

                    //save to task object 
                    Library.TaskManager.Task task = new Library.TaskManager.Task(
                        ((String)item_doc[0][2]), ((String)item_doc[0][3]), ((DateTime)doc[2]),
                        ((bool)doc[3]), ((bool)item_doc[0][5]), ((String)item_doc[0][6]));
                    task.Id = id;
                    temp.Add(task);
                }
            }
            return temp;
        }

        
        public Library.TaskManager.Task AddOrUpdateTask(Library.TaskManager.Task task)
        {
            var dbClient = new MongoClient("mongodb://127.0.0.1:27017");
            var db = dbClient.GetDatabase("TASK_MANAGER_DB");
            var collection = db.GetCollection<BsonDocument>("tasks");
            var item_collection = db.GetCollection<BsonDocument>("items");


            

            Library.TaskManager.Task newTask = null;
            

            
            if (task.Id == Guid.Empty)
            {
                
                newTask = new Library.TaskManager.Task(task.Name, task.Description, task.Deadline,
                    task.IsComplete, task.IsDeleted, task.Priority);
                
                //ADD TO DATABASE TABLES: tasks AND items
                var task_document = new BsonDocument
                {
                    { "id", newTask.Id},
                    { "deadline", task.Deadline },
                    { "isComplete", false }

                };

                var item_document = new BsonDocument
                {
                    { "id", newTask.Id},
                    { "name", task.Name },
                    { "description", task.Description },
                    { "isTask", true },
                    { "isDeleted", false},
                    { "priority", task.Priority }
                };
                collection.InsertOne(task_document);
                item_collection.InsertOne(item_document);
                
                var filter = Builders<BsonDocument>.Filter.Eq("id", newTask.Id);
            }
            else
            {

                
                newTask = new Library.TaskManager.Task(task.Name, task.Description, task.Deadline,
                    task.IsComplete, task.IsDeleted, task.Priority);
                newTask.Id = task.Id;
                
                //locate task in database tables (items and tasks) and update items


                var filter = Builders<BsonDocument>.Filter.Eq("id", task.Id);
                var name_update = Builders<BsonDocument>.Update.Set("name", task.Name);
                var desc_update = Builders<BsonDocument>.Update.Set("description", task.Description);
                var deadline_update = Builders<BsonDocument>.Update.Set("deadline", task.Deadline);
                var priority_update = Builders<BsonDocument>.Update.Set("priority", task.Priority);
                var complete_update = Builders<BsonDocument>.Update.Set("isComplete", task.IsComplete);

                collection.UpdateOne(filter, deadline_update);
                collection.UpdateOne(filter, complete_update);
                item_collection.UpdateOne(filter, name_update);
                item_collection.UpdateOne(filter, desc_update);
                item_collection.UpdateOne(filter, priority_update);
            }

            return newTask;
        }

        public Library.TaskManager.Task DeleteTask(Library.TaskManager.Task task)
        {
            var dbClient = new MongoClient("mongodb://127.0.0.1:27017");
            var db = dbClient.GetDatabase("TASK_MANAGER_DB");
            var collection = db.GetCollection<BsonDocument>("tasks");
            var item_collection = db.GetCollection<BsonDocument>("items");

            //db.DropCollection("items");
            //db.DropCollection("tasks");



            var filter = Builders<BsonDocument>.Filter.Eq("id", task.Id);
            collection.DeleteOne(filter);
            item_collection.DeleteOne(filter);

            return task;
        }

       public List<Library.TaskManager.Task> GetIncompleteTasks()
       {
            List<Library.TaskManager.Task> incompleteTasks = new List<Library.TaskManager.Task>();
            var dbClient = new MongoClient("mongodb://127.0.0.1:27017");
            var db = dbClient.GetDatabase("TASK_MANAGER_DB");
            var collection = db.GetCollection<BsonDocument>("tasks");
            var item_collection = db.GetCollection<BsonDocument>("items");

            var cursor = collection.Find(new BsonDocument()).ToCursor();
            foreach (var doc in cursor.ToList())
            {

                var id = (Guid)doc[1];
               
                var filter = Builders<BsonDocument>.Filter.Eq("id", id);
                var item_cursor = item_collection.Find(filter).ToCursor();
                var item_doc = item_cursor.ToList();

               

                //save to task object 
                Library.TaskManager.Task task = new Library.TaskManager.Task(
                    ((String)item_doc[0][2]), ((String)item_doc[0][3]), ((DateTime)doc[2]),
                    ((bool)doc[3]), ((bool)item_doc[0][5]), ((String)item_doc[0][6]));
                task.Id = id;
                if (!task.IsComplete)
                {
                    incompleteTasks.Add(task);
                }
            }
            return incompleteTasks;
       }
    }
}