﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Library.TaskManager;
using MongoDB.Bson;
using MongoDB.Driver;

namespace TaskManagerAPI.Controllers.EC
{
    public class CalendarAppointmentEC
    {
        public List<CalendarAppointments> GetAppts()
        {
            List<CalendarAppointments> appts = new List<CalendarAppointments>();

            var results = new List<Item>();
            var dbClient = new MongoClient("mongodb://127.0.0.1:27017");
            var db = dbClient.GetDatabase("TASK_MANAGER_DB");
            var collection = db.GetCollection<BsonDocument>("calendar_appts");
            var item_collection = db.GetCollection<BsonDocument>("items");


            var cursor = collection.Find(new BsonDocument()).ToCursor();
            
            foreach (var doc in cursor.ToList())
            {
                
                var id = (Guid)doc[1];
                
                var filter = Builders<BsonDocument>.Filter.Eq("id", id);
                var item_cursor = item_collection.Find(filter).ToCursor();
                var item_doc = item_cursor.ToList();
     
                //parse list with ',' delimiter
                
                string attendee_string = (string)doc[4];
                string[] attendees_array = attendee_string.Split(',');
                List <string> attendees = attendees_array.ToList();

                CalendarAppointments temp = new CalendarAppointments(
                    (String)item_doc[0][2], (String)item_doc[0][3], (DateTime)doc[2],
                    (DateTime)doc[3], attendees, (bool)item_doc[0][5], (String)item_doc[0][6]);
                temp.Id = id;
                appts.Add(temp);
            }
                return appts;
        }

        public CalendarAppointments AddOrUpdateAppts(CalendarAppointments appt)
        {
            CalendarAppointments newAppt = null;

            var dbClient = new MongoClient("mongodb://127.0.0.1:27017");
            var db = dbClient.GetDatabase("TASK_MANAGER_DB");
            var collection = db.GetCollection<BsonDocument>("calendar_appts");
            var item_collection = db.GetCollection<BsonDocument>("items");

            string attendees = "";

            foreach(var a in appt.Attendees)
            {
                attendees += a + ",";
            }


            if (appt.Id == Guid.Empty)
            {


                //////ADD TO DATABASE TABLES: tasks AND items

                newAppt = new CalendarAppointments(appt.Name, appt.Description, appt.Start,
                    appt.Stop, appt.Attendees, appt.IsDeleted, appt.Priority);
                var appt_document = new BsonDocument
                {
                    { "id", newAppt.Id},
                    { "start", appt.Start },
                    { "stop", appt.Stop},
                    { "attendees", attendees }

                };

                var item_document = new BsonDocument
                {
                    { "id", newAppt.Id},
                    { "name", appt.Name },
                    { "description", appt.Description },
                    { "isTask", false },
                    { "isDeleted", false},
                    { "priority", appt.Priority }
                };
                collection.InsertOne(appt_document);
                item_collection.InsertOne(item_document);
            }
            else
            {
                
                newAppt = new CalendarAppointments(appt.Name, appt.Description, appt.Start,
                   appt.Stop, appt.Attendees, appt.IsDeleted, appt.Priority);
                newAppt.Id = appt.Id;


                ////locate task in database tables (items and calendar_appts) and update items


                var filter = Builders<BsonDocument>.Filter.Eq("id", appt.Id);
                var name_update = Builders<BsonDocument>.Update.Set("name", appt.Name);
                var desc_update = Builders<BsonDocument>.Update.Set("description", appt.Description);
                var start_update = Builders<BsonDocument>.Update.Set("start", appt.Start);
                var stop_update = Builders<BsonDocument>.Update.Set("stop", appt.Stop);
                var attendees_update = Builders<BsonDocument>.Update.Set("attendees", attendees);
                var priority_update = Builders<BsonDocument>.Update.Set("priority", appt.Priority);


                collection.UpdateOne(filter, start_update);
                collection.UpdateOne(filter, stop_update);
                collection.UpdateOne(filter, attendees_update);
                item_collection.UpdateOne(filter, name_update);
                item_collection.UpdateOne(filter, desc_update);
                item_collection.UpdateOne(filter, priority_update);
            }

            return newAppt;

        }

        public CalendarAppointments DeleteAppt(CalendarAppointments appt)
        {
            var dbClient = new MongoClient("mongodb://127.0.0.1:27017");
            var db = dbClient.GetDatabase("TASK_MANAGER_DB");
            var collection = db.GetCollection<BsonDocument>("calendar_appts");
            var item_collection = db.GetCollection<BsonDocument>("items");



            //db.DropCollection("items");
            //db.DropCollection("calendar_appts");

            var filter = Builders<BsonDocument>.Filter.Eq("id", appt.Id);
            collection.DeleteOne(filter);
            item_collection.DeleteOne(filter);

            return appt;
        }
    }
}
