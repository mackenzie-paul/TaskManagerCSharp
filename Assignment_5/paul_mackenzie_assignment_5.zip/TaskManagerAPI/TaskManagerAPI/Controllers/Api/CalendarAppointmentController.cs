﻿//Mackenzie Paul
//Assignment 5

using System;
using System.Collections.Generic;
using System.Linq;
using Library.TaskManager;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using MongoDB.Driver;
using TaskManagerAPI.Controllers.EC;

namespace TaskManagerAPI.Controllers
{
    [ApiController]
    [Route("Appointment")]
    public class CalendarAppointmentController : ControllerBase
    {

        [HttpGet("test")]
        public string Test()
        {
            return "Appointment Controller";
        }


        //returns list of appointments
        [HttpGet("GetAppt")]
        public ActionResult<List<Item>> GetAppts()
        {   
            return Ok(new CalendarAppointmentEC().GetAppts());
        }

        //adds or updates appointments
        [HttpPost("AddOrUpdateAppt")]
        public ActionResult<CalendarAppointments> AddOrUpdateAppt(CalendarAppointments appt)
        {
            return Ok(new CalendarAppointmentEC().AddOrUpdateAppts(appt));
        }

        //deletes appointment
        [HttpPost("DeleteAppt")]
        public ActionResult<CalendarAppointments> DeleteAppt(CalendarAppointments appt)
        {
            return Ok(new CalendarAppointmentEC().DeleteAppt(appt));
        }
    }
}

