﻿//Mackenzie Paul
//Assignment 5

using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Library.TaskManager;
using System.Linq;
using TaskManagerAPI.Controllers.EC;

namespace TaskManagerAPI.Controllers
{
    [ApiController]
    [Route("Task")]
    public class TaskController : ControllerBase
    {

        [HttpGet("test")]
        public string Test()
        {
            return "Task Controller Test";
        }

        //returns entire data context list
        [HttpGet("GetAll")]
        public ActionResult<List<Item>> GetAsync()
        { 
            return Ok(new TaskEC().Get());
        }

        //returns tasks
        [HttpGet("GetTask")]
        public  ActionResult<List<Task>> GetTasks()
        {
            return (Ok(new TaskEC().GetTasksAsync()));
        }

        //adds or updates tasks
        [HttpPost("AddOrUpdateTask")]
        public ActionResult<Task> AddOrUpdateTask(Task task)
        {
            return Ok(new TaskEC().AddOrUpdateTask(task));
        }

        //deletes tasks
        [HttpPost("DeleteTask")]
        public ActionResult<Task> DeleteTask( Task task)
        {            
            return Ok(new TaskEC().DeleteTask(task));
        }

        
        [HttpGet("GetSearchResults")]
        public ActionResult<List<Item>> GetSearchResults(string search_item)
        {

            List<Item> searchResults = new List<Item>();
            List<Task> tasksToCheck = new TaskEC().GetTasksAsync();
            List<CalendarAppointments> apptsToCheck = new CalendarAppointmentEC().GetAppts();

            var task_item =
                from task in tasksToCheck
                where task.IsTask == true && (
                task.Name.Contains(search_item) ||
                task.Description.Contains(search_item))
                select task;

            var appt_item =
                from appt in apptsToCheck
                where appt.IsTask == false && (
                appt.Name.Contains(search_item) ||
                appt.Description.Contains(search_item) ||
                appt.Attendees.Contains(search_item))
                select appt;


            foreach (var task in task_item)
            {
                searchResults.Add(task);
            }
            foreach (var appt in appt_item)
            {
                searchResults.Add(appt);
            }
            return Ok(searchResults.Select(t => new Item(t)).ToList());
        }

        //finds and returns incomplete tasks
        [HttpGet("GetIncompleteTasks")]
        public ActionResult<List<Task>> GetIncompleteTasks()
        {
            return Ok(new TaskEC().GetIncompleteTasks());
        }
    }

    
}
