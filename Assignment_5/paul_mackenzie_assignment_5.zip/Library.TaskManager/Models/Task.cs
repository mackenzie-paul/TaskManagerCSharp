﻿//Mackenzie Paul
//Assignment 3 (Modified from Assignment 2)


using System;
using System.Collections.Generic;

namespace Library.TaskManager
{
    [Serializable]
    public class Task : Item
    {


        //deadline
        DateTime deadline;
        public override DateTime Deadline
        {
            get
            {
                return deadline;
            }
            set
            {
                deadline = value;
            }
        }

        //isComplete
        bool isComplete;
        public override bool IsComplete
        {
            get
            {
                return isComplete;
            }
            set
            {
                isComplete = value;
            }
        }

        public override string Preview
        {
            get
            {

                if (Priority.Equals("Low"))
                {
                    return "\t   Task:  " + Name + " - " + Description + "\n\tDeadline: "
                        + Deadline.ToString("MMM dd, yyyy");
                }
                else if (Priority.Equals("Medium"))
                {
                    return "\t!  Task:  " + Name + " - " + Description + "\n\tDeadline: "
                        + Deadline.ToString("MMM dd, yyyy");
                }
                else
                {
                    return "\t!! Task:  " + Name + " - " + Description + "\n\tDeadline: "
                        + Deadline.ToString("MMM dd, yyyy");
                }


            }
            set { }
        }

        public Task()
        {
            Id = Guid.Empty;


        }

        public Task(Task task)
        {
            Id = task.Id;
            Name = task.Name;
            Description = task.Description;
            Deadline = task.Deadline;
            IsComplete = task.IsComplete;
            IsDeleted = false;
            IsTask = true;
            Priority = task.Priority;
        }

        public Task(string name, string description, DateTime deadline,
            bool isComplete, bool isDeleted, string priority)
            :base(name, description, isDeleted, true, priority) {
            
            this.Deadline = deadline;
            this.IsComplete = isComplete;
        }

        

        public override string ToString()
        {
            
            var task_info = "Task:  " + Name + " - " + Description + "\nDeadline: "
                + Deadline.ToString("MMM dd, yyyy") + "";
            return task_info;
        }
    }
}
