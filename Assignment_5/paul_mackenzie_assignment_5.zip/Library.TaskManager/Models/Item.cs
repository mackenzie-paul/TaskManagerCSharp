﻿//Mackenzie Paul
//Assignment 3 (Modified from Assignment 2)


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Library.TaskManager
{
    [Serializable]
    public class Item : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public Guid Id
        {get; set;}

        private string name;
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
                NotifyPropertyChanged();
            }

        }

        private string description;
        public string Description
        {
            get
            {
                return description;
            }
            set
            {
                description = value;
                NotifyPropertyChanged();
            }
        }

        private bool isDeleted;
        public bool IsDeleted
        {
            get
            {
                return isDeleted;
            }
            set
            {
                isDeleted = value;
                NotifyPropertyChanged();
            }
        }

        bool isTask;
        public bool IsTask
        {
            get
            {
                return isTask;
            }
            set
            {
                isTask = value;
                NotifyPropertyChanged();
            }
        }
        string priority;
        public string Priority
        {
            get
            {
                return priority;

            }
            set
            {
                priority = value;
                NotifyPropertyChanged();
            }
        }

        public virtual DateTime Deadline { get; set; }
        public virtual bool IsComplete { get; set; }
        public virtual DateTime Start { get; set; }
        public virtual DateTime Stop { get; set; }
        public virtual List<string> Attendees { get; set; }

        public virtual string Preview {
            get
            {
                if (!IsTask)
                {
                    if (Priority.Equals("Low"))
                    {
                        return $"\t   Appointment:  {Name} - {Description} \n\t Start Date: {Start.ToString("MMM dd, yyyy")}" +
                        $"\t End Date: {Stop.ToString("MMM dd, yyyy")}";
                    }
                    else if (Priority.Equals("Medium"))
                    {
                        return $"\t!  Appointment:  {Name} - {Description} \n\t Start Date: {Start.ToString("MMM dd, yyyy")}" +
                        $"\t End Date: {Stop.ToString("MMM dd, yyyy")}";
                    }
                    else
                    {
                        return $"\t!! Appointment:  {Name} - {Description} \n\t Start Date: {Start.ToString("MMM dd, yyyy")}" +
                        $"\t End Date: {Stop.ToString("MMM dd, yyyy")}";
                    }
                }
                else
                {
                    if (Priority.Equals("Low"))
                    {
                        return "\t   Task:  " + Name + " - " + Description + "\n\tDeadline: "
                            + Deadline.ToString("MMM dd, yyyy");
                    }
                    else if (Priority.Equals("Medium"))
                    {
                        return "\t!  Task:  " + Name + " - " + Description + "\n\tDeadline: "
                            + Deadline.ToString("MMM dd, yyyy");
                    }
                    else
                    {
                        return "\t!! Task:  " + Name + " - " + Description + "\n\tDeadline: "
                            + Deadline.ToString("MMM dd, yyyy");
                    }
                }
            }
            set
            {

            } }

        public Item() { }

        public Item(string name, string description, bool isDeleted, bool isTask, string priority)
        {
            this.Name = name;
            this.Description = description;
            this.IsDeleted = isDeleted;
            this.IsTask = isTask;
            this.Priority = priority;
            Id = Guid.NewGuid();

            
        }

        public Item(Item item)
        {
            this.Name = item.Name;
            this.Description = item.Description;
            this.IsDeleted = item.IsDeleted;
            this.IsTask = item.IsTask;
            this.Priority = item.Priority;
            this.Id = item.Id;
            this.Deadline = item.Deadline;
            this.IsComplete = item.IsComplete;
            this.Start = item.Start;
            this.Stop = item.Stop;
            this.Attendees = item.Attendees;
        }

        public virtual string ToString()
        {
            
                return $"{Name} - {Description} \n\t";
            
        }
        
    }
}
