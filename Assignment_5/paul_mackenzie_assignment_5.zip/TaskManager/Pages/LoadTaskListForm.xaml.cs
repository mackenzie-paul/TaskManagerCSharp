﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Library.TaskManager;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TaskManager.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class LoadTaskListForm : ContentPage
    {
        private ICollection<Item> tasksAndAppts;
        public LoadTaskListForm(ICollection<Item> tasksAndAppts)
        {
            InitializeComponent();
            this.tasksAndAppts = tasksAndAppts;
        }

        public void Back_Clicked(object sender, EventArgs e)
        {
            Navigation.PopModalAsync();
        }

        public async void Load_Clicked(object sender, EventArgs e)
        {
            //THIS IS WHERE WE LOAD FROM OUR MACHINE

            string file_name_entry = load_name.Text;

            if (file_name_entry.Equals(""))
            {
                load_name_label.TextColor = Color.Red;
                _ = DisplayAlert("Missing File Name", "Please enter a valid file name.", "Cancel");
            }
            else
            {
                //adds '.json' to list name entered
                file_name_entry = file_name_entry + ".json";
                load_name_label.TextColor = Color.Gray;
                var directory = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

                var combine_path = Path.Combine(directory, file_name_entry);

                //if file exists, deserializes its contents and loads into main list
                if (File.Exists(combine_path))
                {
                    using (StreamReader file = File.OpenText(combine_path))
                    {
                        JsonSerializer serializer = new JsonSerializer();
                        ICollection<Item> taskA = (ICollection<Item>)serializer.Deserialize(file, typeof(ICollection<Item>));
                        

                        foreach (var item in taskA)
                        {
                            if (item.IsTask)
                            {
                                item.Id = Guid.Empty;
                                var handler = new WebRequestHandler();
                                var thisAppt = item;
                                thisAppt = JsonConvert.DeserializeObject<CalendarAppointments>
                                    (await new WebRequestHandler().Post("http://10.0.2.2:5000/Task/AddOrUpdateTask",
                                    thisAppt));
                            }
                            else
                            {
                                item.Id = Guid.Empty;
                                var handler = new WebRequestHandler();
                                var thisAppt = item;
                                thisAppt = JsonConvert.DeserializeObject<CalendarAppointments>
                                    (await new WebRequestHandler().Post("http://10.0.2.2:5000/Appointment/AddOrUpdateAppt",
                                    thisAppt));
                            }
                            tasksAndAppts.Add(item);
                        }
                    }
                    _ = Navigation.PopModalAsync();
                }
                else
                {
                    //print file does not exist and let user enter again
                    _ = DisplayAlert("List Not Found", "Please try another list name.", "Cancel");
                }
            }
        }
    }
}
