﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;
using Newtonsoft.Json;
using Library.TaskManager;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TaskManager.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    [Serializable]
    public partial class SaveTaskListForm : ContentPage
    {


        private ICollection<Item> tasksAndAppts;
        public SaveTaskListForm(ICollection<Item> tasksAndAppts)
        {
            InitializeComponent();
            this.tasksAndAppts = tasksAndAppts;
        }

        public void Back_Clicked(object sender, EventArgs e)
        {
            Navigation.PopModalAsync();
        }

        public void Save_Clicked(object sender, EventArgs e)
        {
            //THIS IS WHERE WE SAVE TO OUR MACHINE
            string file_name_entry = save_name.Text;

            //checks if file name already exists
            if (file_name_entry.Equals(""))
            {
                save_name_label.TextColor = Color.Red;
                DisplayAlert("Missing File Name", "Please enter a valid file name.", "Cancel");
            }
            else
            {
                //adds '.json' to list name
                file_name_entry = file_name_entry + ".json";
                save_name_label.TextColor = Color.Gray;

                var directory = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

                var combine_path = Path.Combine(directory, file_name_entry);

                //serializes object and adds to file
                var f = JsonConvert.SerializeObject(tasksAndAppts);
                if (!File.Exists(combine_path))
                {
                    var fs = new FileStream(combine_path, FileMode.Create);
                    fs.Dispose();
                    File.WriteAllText(combine_path, f);
                    Navigation.PopModalAsync();
                }
                else
                {
                    //display to user that file name already taken
                    DisplayAlert("List Already Exists", "Please enter a new list name.", "Cancel");

                }

            }

        }
    }
}
