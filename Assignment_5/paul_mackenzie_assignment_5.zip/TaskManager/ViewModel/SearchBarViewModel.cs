﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using Library.TaskManager;

namespace TaskManager
{
    public class SearchBarViewModel : INotifyPropertyChanged

    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private string search_item;
        public string Search_Item
        {
            get
            {
                return search_item;
            }
            set
            {
                search_item = value;
                NotifyPropertyChanged();
            }
        }


        ObservableCollection<Item> collection;
        public ObservableCollection<Item> Collection
        {
            get
            {
                return collection;
            }

            set
            {
                collection = value;
                NotifyPropertyChanged();
            }
        }

       

        public SearchBarViewModel(string search_item, ObservableCollection<Item> collection)
        {
            this.search_item = search_item;
            this.collection = collection;
        }

        private List<Item> searchResults;
        public List<Item> SearchResults
        {
            get
            {
                return searchResults;
            }

            set
            {
                searchResults = value;
                NotifyPropertyChanged();
            }
        }

        public void Perform_Search()
        {
            List<Item> temp_list = new List<Item>();

            //use LINQ
            var task_item =
                from task in Collection
                where task.IsTask == true && (
                task.Name.Contains(search_item) ||
                task.Description.Contains(search_item))
                select task;

            var appt_item =
                from appt in Collection
                where appt.IsTask == false && (
                appt.Name.Contains(search_item) ||
                appt.Description.Contains(search_item) ||
                appt.Attendees.Contains(search_item))
                select appt;


            foreach(var task in task_item)
            {
                temp_list.Add(task);
            }
            foreach(var appt in appt_item)
            {
                temp_list.Add(appt);
            }

            SearchResults = temp_list;
            
        }
    }
}
