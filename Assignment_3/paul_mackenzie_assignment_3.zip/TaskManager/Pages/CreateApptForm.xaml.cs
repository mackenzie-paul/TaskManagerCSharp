﻿using System;
using System.Collections.Generic;
using TaskManager.ViewModel;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TaskManager.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CreateApptForm : ContentPage
    {
        private ICollection<Item> tasksAndAppts;
        List<string> attendees;
        public CreateApptForm(ICollection<Item> tasksAndAppts)
        {
            InitializeComponent();
            this.tasksAndAppts = tasksAndAppts;
            attendees = new List<string>();
            BindingContext = new CalendarAppointments("", "", DateTime.Now, DateTime.Now, attendees, false, "Low");

        }

        public void Back_Clicked(object sender, EventArgs e)
        {
            Navigation.PopModalAsync();
        }

        public void Create_Clicked(object sender, EventArgs e)
        {

            bool all_fields_pass = true;

            //verfies all fields have entries
            string appt_name_string = appt_name_entry.Text;
            if (appt_name_string.Equals(""))
            {
                appt_name.TextColor = Color.Red;
                all_fields_pass = false;
            }
            else
            {
                appt_name.TextColor = Color.Gray;
            }

            string appt_desc_string = appt_desc_entry.Text;
            if (appt_desc_string.Equals(""))
            {
                appt_desc.TextColor = Color.Red;
                all_fields_pass = false;
            }
            else
            {
                appt_desc.TextColor = Color.Gray;
            }

            if (all_fields_pass)
            {
                //checks priority
                if (med_priority.IsChecked)
                {
                    (BindingContext as CalendarAppointments).Priority = "Medium";
                }
                else if (high_priority.IsChecked)
                {
                    (BindingContext as CalendarAppointments).Priority = "High";
                }

                (BindingContext as CalendarAppointments).Attendees = attendees;
                tasksAndAppts.Add(BindingContext as CalendarAppointments);
                Navigation.PopModalAsync();
            }
            else
            {
                DisplayAlert("Information Missing","Please Check All Fields.", "Cancel");
            }
            
        }

        //if attendee is added -> added to local list that is saved to BindingContext
        public void Add_Attendee(object sender, EventArgs e)

        {
            
            var attendee = attendee_entry.Text;
            if (!attendee.Equals(""))
            {
                attendees.Add(attendee);
            }
            else
            {
                DisplayAlert("Add Attendee", "Make sure to enter attendee's name.", "Cancel");
            }
            attendee_entry.Text = "";
        }

        public async void Show_List(object sender, EventArgs e)
        {
            string [] attendee_array = attendees.ToArray();
            string incomplete_task_action = await DisplayActionSheet("Attendees:", "Cancel", null, attendee_array);
        }
    }
}
