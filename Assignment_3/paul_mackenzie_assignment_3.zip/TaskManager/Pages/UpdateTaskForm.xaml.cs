﻿using System;
using System.Collections.Generic;
using TaskManager.ViewModel;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TaskManager.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class UpdateTaskForm : ContentPage
    {


        private ICollection<Item> tasksAndAppts;
        public UpdateTaskForm(ICollection<Item> tasksAndAppts, Item updateItem)
        {
            InitializeComponent();
            this.tasksAndAppts = tasksAndAppts;
            BindingContext = updateItem;
        }

        public void Back_Clicked(object sender, EventArgs e)
        {
            Navigation.PopModalAsync();
        }

        public void Update_Clicked(object sender, EventArgs e)
        {
            bool all_fields_pass = true;

            //checks that all fields have entries
            string task_name_string = task_name_entry.Text;
            if (task_name_string.Equals(""))
            {
                task_name.TextColor = Color.Red;
                all_fields_pass = false;
            }
            else
            {
                task_name.TextColor = Color.Gray;
            }

            string task_desc_string = task_desc_entry.Text;
            if (task_desc_string.Equals(""))
            {
                task_desc.TextColor = Color.Red;
                all_fields_pass = false;
            }
            else
            {
                task_desc.TextColor = Color.Gray;
            }

            

            if (all_fields_pass)
            {
                tasksAndAppts.Remove(BindingContext as Task);

                //checks priority
                if (low_priority.IsChecked)
                {
                    (BindingContext as Task).Priority = "Low";
                }
                else if (med_priority.IsChecked)
                {
                    (BindingContext as Task).Priority = "Medium";
                }
                else if (high_priority.IsChecked)
                {
                    (BindingContext as Task).Priority = "High";
                }

                //replaces old object
                tasksAndAppts.Add((BindingContext as Task));
                Navigation.PopModalAsync();
            }
            else
            {
                DisplayAlert("Missing Information", "Pleas check all fields.", "Cancel");
            }
        }
    }
}
