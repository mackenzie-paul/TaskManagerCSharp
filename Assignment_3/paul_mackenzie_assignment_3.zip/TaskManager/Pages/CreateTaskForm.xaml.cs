﻿using System;
using System.Collections.Generic;
using TaskManager.ViewModel;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TaskManager.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CreateTaskForm : ContentPage
    {
        

        private ICollection<Item> tasksAndAppts;
        public CreateTaskForm(ICollection<Item> tasksAndAppts)
        {
            InitializeComponent();
            this.tasksAndAppts = tasksAndAppts;
            BindingContext = new Task("", "", DateTime.Now, false, true, "Low");
        }

        public void Back_Clicked(object sender, EventArgs e)
        {
            Navigation.PopModalAsync();
        }

        public void Create_Clicked(object sender, EventArgs e)
        {
            bool all_fields_pass = true;

            //validates all fields have entries
            string task_name_string = task_name_entry.Text;
            if (task_name_string.Equals(""))
            {
                task_name.TextColor = Color.Red;
                all_fields_pass = false;
            }
            else
            {
                task_name.TextColor = Color.Gray;
            }

            string task_desc_string = task_desc_entry.Text;
            if (task_desc_string.Equals(""))
            {
                task_desc.TextColor = Color.Red;
                all_fields_pass = false;
            }
            else
            {
                task_desc.TextColor = Color.Gray;
            }

            

            if (all_fields_pass)
            {

                //checks priority
                if (med_priority.IsChecked)
                {
                    (BindingContext as Task).Priority = "Medium";
                }else if (high_priority.IsChecked)
                {
                    (BindingContext as Task).Priority = "High";
                }
                tasksAndAppts.Add((BindingContext as Task));
                Navigation.PopModalAsync();
            }
            else
            {
                DisplayAlert("Missing Information", "Please check all fields.", "Cancel");
            }
        }
    }
}