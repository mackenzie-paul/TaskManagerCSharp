﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using TaskManager.ViewModel;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TaskManager.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class LoadTaskListForm : ContentPage
    {
        private ICollection<Item> tasksAndAppts;
        public LoadTaskListForm(ICollection<Item> tasksAndAppts)
        {
            InitializeComponent();
            this.tasksAndAppts = tasksAndAppts;
        }

        public void Back_Clicked(object sender, EventArgs e)
        {
            Navigation.PopModalAsync();
        }

        public void Load_Clicked(object sender, EventArgs e)
        {
            //THIS IS WHERE WE LOAD FROM OUR MACHINE

            string file_name_entry = load_name.Text;

            if (file_name_entry.Equals(""))
            {
                load_name_label.TextColor = Color.Red;
                DisplayAlert("Missing File Name", "Please enter a valid file name.", "Cancel");
            }
            else
            {
                //adds '.json' to list name entered
                file_name_entry = file_name_entry + ".json";
                load_name_label.TextColor = Color.Gray;
                var directory = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

                var combine_path = Path.Combine(directory, file_name_entry);

                //if file exists, deserializes its contents and loads into main list
                if (File.Exists(combine_path))
                {
                    using (StreamReader file = File.OpenText(combine_path))
                    {
                        JsonSerializer serializer = new JsonSerializer();
                        ICollection<Item> taskA = (ICollection<Item>)serializer.Deserialize(file, typeof(ICollection<Item>));
                        tasksAndAppts.Clear();

                        foreach (var item in taskA)
                        {
                            if (item.IsTask)
                            {
                                BindingContext = new ViewModel.Task(item.Name, item.Description,
                                    item.Deadline, item.IsComplete, item.IsDeleted, item.Priority);
                                tasksAndAppts.Add(BindingContext as ViewModel.Task);

                            }
                            else
                            {
                                BindingContext = new ViewModel.CalendarAppointments(item.Name, item.Description,
                                    item.Start, item.Stop, item.Attendees, item.IsDeleted, item.Priority);
                                tasksAndAppts.Add(BindingContext as ViewModel.CalendarAppointments);
                            }
                            
                        }
                    }
                    Navigation.PopModalAsync();
                }
                else
                {
                    //print file does not exist and let user enter again
                    DisplayAlert("List Not Found", "Please try another list name.", "Cancel");
                }
            }
        }
    }
}
