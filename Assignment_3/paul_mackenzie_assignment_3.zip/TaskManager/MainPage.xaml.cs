﻿//Mackenzie Paul
//Assignment 3

using System;
using System.Collections.Generic;
using TaskManager.Pages;
using TaskManager.ViewModel;
using Xamarin.Forms;


namespace TaskManager
{
    public partial class MainPage : ContentPage
    {
        private ListView list;

        public MainPage()
        {
            InitializeComponent();
            BindingContext = new MainViewModel();
            list = (task_listview);
        }
        
        private async void Search_Clicked(object sender, EventArgs e)
        {
            
            SearchBar searchBar = (SearchBar)sender;
            SearchBarViewModel searchVals = new SearchBarViewModel(searchBar.Text, (BindingContext as MainViewModel).TaskAndAppts);

            searchVals.Perform_Search();
            List<Item> vals = searchVals.SearchResults;
            List<string> printout = new List<string>();
            foreach(var val in vals)
            {
                printout.Add(val.Preview);
            }

            string[] tAndA = printout.ToArray();
            string action = await DisplayActionSheet("Tasks and Appointments Found:", "Cancel", null, tAndA);
        }

        private async void Options_Clicked(object sender, EventArgs e)
        {
            string[] buttons = {"Create Task", "Create Appointment", "Edit", "Delete", "List Incomplete Tasks",
                "Sort by Priority", "Display All","Display Tasks", "Display Appointments", "Complete Task",
                "Save List", "Load List"};
            string action = await DisplayActionSheet("Select one: ", "Cancel", null, buttons);
            
            switch (action)
            {
                
                case "Create Task":
                    var task_diag = new CreateTaskForm((BindingContext as MainViewModel).TaskAndAppts);
                    _ = Navigation.PushModalAsync(task_diag);
                    break;
                case "Create Appointment":
                    
                    var appt_diag = new CreateApptForm((BindingContext as MainViewModel).TaskAndAppts);
                    _ = Navigation.PushModalAsync(appt_diag);
                    break;

                case "Edit":
                    if ((BindingContext as MainViewModel).SelectedItem != null)
                    {
                        if ((BindingContext as MainViewModel).SelectedItem.IsTask)
                        {
                            //edit task

                            var edit_task_diag = new UpdateTaskForm((BindingContext as MainViewModel).TaskAndAppts,
                                (BindingContext as MainViewModel).SelectedItem);
                            _ = Navigation.PushModalAsync(edit_task_diag);
                        }
                        else if (!(BindingContext as MainViewModel).SelectedItem.IsTask)
                        {
                            //edit appointment
                            var edit_appt_diag = new UpdateApptForm((BindingContext as MainViewModel).TaskAndAppts,
                                (BindingContext as MainViewModel).SelectedItem);
                            _ = Navigation.PushModalAsync(edit_appt_diag);
                        }
                    }
                    else
                    {
                        _ = DisplayAlert("No Item Selected.", "Please select an item from the list.", "Cancel");
                    }
                    break;

                case "Delete":
                    (BindingContext as MainViewModel).Remove();
                    break;

                case "List Incomplete Tasks":
                    List<string> incomplete_task_list = new List<string>();
                    foreach (var task in (BindingContext as MainViewModel).TaskAndAppts)
                    {
                        if (task.IsTask && !task.IsComplete)
                        {
                            incomplete_task_list.Add(task.Preview);
                        }
                    }
                    string[] incomplete_task_array = incomplete_task_list.ToArray();
                    string incomplete_task_action = await DisplayActionSheet("Tasks:", "Cancel", null, incomplete_task_array);

                    break;

                case "Sort by Priority":
                    List<Item> temp_list = new List<Item>();
                    foreach (var item in (BindingContext as MainViewModel).TaskAndAppts)
                    {
                        if (item.Priority.Equals("High"))
                        {
                            temp_list.Add(item);
                        }
                    }

                    foreach (var item in (BindingContext as MainViewModel).TaskAndAppts)
                    {
                        if (item.Priority.Equals("Medium"))
                        {
                            temp_list.Add(item);
                        }
                    }

                    foreach (var item in (BindingContext as MainViewModel).TaskAndAppts)
                    {
                        if (item.Priority.Equals("Low"))
                        {
                            temp_list.Add(item);
                        }
                    }

                    (BindingContext as MainViewModel).TaskAndAppts.Clear();
                    foreach (var item in temp_list)
                    {
                        (BindingContext as MainViewModel).TaskAndAppts.Add(item);
                    }
                    list.ItemsSource = (BindingContext as MainViewModel).TaskAndAppts;
                    break;

                case "Display All":
                    list.ItemsSource = (BindingContext as MainViewModel).TaskAndAppts;
                    list.SelectedItem = (BindingContext as MainViewModel).SelectedItem;
                    break;

                case "Display Tasks":
                    List<string> task_list = new List<string>();
                    
                    foreach (var task in (BindingContext as MainViewModel).TaskAndAppts)
                    {
                        if(task.IsTask)
                        {
                            task_list.Add(task.Preview);
                        }
                    }
                    string[] task_array = task_list.ToArray();

                    string task_action = await DisplayActionSheet("Tasks:", "Cancel", null, task_array);
                    break;

                case "Display Appointments":
                    List<string> appt_list = new List<string>();

                    foreach (var appt in (BindingContext as MainViewModel).TaskAndAppts)
                    {
                        if (!appt.IsTask)
                        {
                            appt_list.Add(appt.Preview);
                        }
                    }
                    string[] appt_array = appt_list.ToArray();

                    string appt_action = await DisplayActionSheet("Appointments:", "Cancel", null, appt_array);
                    break;
                case "Complete Task":
                    if ((BindingContext as MainViewModel).SelectedItem != null &&
                        (BindingContext as MainViewModel).SelectedItem.IsTask)
                    {
                        (BindingContext as MainViewModel).SelectedItem.IsComplete = true;
                    }
                    else
                    {
                        _ = DisplayAlert("Task Not Selected", "Please select a task to complete.", "Cancel");
                    }
                    break;
                case "Save List":
                    //ask user for the save name
                    //save task_list to user's file
                    var save_list_diag = new SaveTaskListForm((BindingContext as MainViewModel).TaskAndAppts);
                    _ = Navigation.PushModalAsync(save_list_diag);
                    break;
                case "Load List":
                    //ask for a name to open task_list
                    //open saved task_list
                    var load_list_diag = new LoadTaskListForm((BindingContext as MainViewModel).TaskAndAppts);
                    _ = Navigation.PushModalAsync(load_list_diag);
                    break;
            }
        }
    }
}