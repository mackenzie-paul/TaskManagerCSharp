﻿//Mackenzie Paul
//Assignment 3 (Modified from Assignment 2)


using System;
using System.Collections.Generic;

namespace TaskManager.ViewModel
{
    [Serializable]
    public class CalendarAppointments : Item
    {
       

        private DateTime start;
        public override DateTime Start { get
            {
                return start;
            }
            set
            {
                start = value;
            }
        }
        private DateTime stop;
        public override DateTime Stop
        {
            get
            {
                return stop;
            }
            set
            {
                stop = value;
            }
        }

        //added to help with printout 
        public override string Preview
        {
            get
            {
                string task_info = "";
                foreach (var attendee in Attendees)
                {
                    task_info += attendee + "\n";
                }
                if (Priority.Equals("Low"))
                {
                    return $"\t   Appointment:  {Name} - {Description} \n\t Start Date: {Start.ToString("MMM dd, yyyy")}" +
                    $"\t End Date: {Stop.ToString("MMM dd, yyyy")}\nAttendees:\n" + task_info;
                }
                else if (Priority.Equals("Medium"))
                {
                    return $"\t!  Appointment:  {Name} - {Description} \n\t Start Date: {Start.ToString("MMM dd, yyyy")}" +
                    $"\t End Date: {Stop.ToString("MMM dd, yyyy")}\nAttendees:\n" + task_info;
                }
                else
                {
                    return $"\t!! Appointment:  {Name} - {Description} \n\t Start Date: {Start.ToString("MMM dd, yyyy")}" +
                    $"\t End Date: {Stop.ToString("MMM dd, yyyy")}"+ "\nAttendees:\n" + task_info;
                }

                
            }
            set { }
        }

        private List<string> attendees;
        public override List<string> Attendees
        {
            get
            {
                return attendees;
            }

            set
            {
                attendees = value;
            }
        }

        public CalendarAppointments(string name, string description,
            DateTime start, DateTime stop, List<string> attendees, bool isDeleted, string priority)
            : base(name, description, isDeleted, false, priority)
        {
            this.Start = start;
            this.Stop = stop;
            this.Attendees = attendees;
                
        }

        public override string ToString(bool val)
        {

            var task_info = $"Appointment:  {Name} - {Description} \n\t Start Date: {Start.ToString("MMM dd, yyyy")}\n" +
                $"\t End Date: {Stop.ToString("MMM dd, yyyy")}\nAttendees:\n";
            //print out list of attendees
            foreach (var attendee in Attendees)
            {
                task_info += attendee + "\n";
            }

            return task_info;
        }
    }
}
    

