﻿//Mackenzie Paul
//Assignment 3 (Modified from Assignment 2)


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace TaskManager.ViewModel
{
    [Serializable]
    public class Item : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public Guid Id
        {get; set;}

        private string name;
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
                NotifyPropertyChanged();
            }

        }

        private string description;
        public string Description
        {
            get
            {
                return description;
            }
            set
            {
                description = value;
                NotifyPropertyChanged();
            }
        }

        private bool isDeleted;
        public bool IsDeleted
        {
            get
            {
                return isDeleted;
            }
            set
            {
                isDeleted = value;
                NotifyPropertyChanged();
            }
        }

        bool isTask;
        public bool IsTask
        {
            get
            {
                return isTask;
            }
            set
            {
                isTask = value;
                NotifyPropertyChanged();
            }
        }
        string priority;
        public string Priority
        {
            get
            {
                return priority;

            }
            set
            {
                priority = value;
                NotifyPropertyChanged();
            }
        }

        public virtual DateTime Deadline { get; set; }
        public virtual bool IsComplete { get; set; }
        public virtual DateTime Start { get; set; }
        public virtual DateTime Stop { get; set; }
        public virtual List<string> Attendees { get; set; }

        public virtual string Preview { get; set; }

        public Item(string name, string description, bool isDeleted, bool isTask, string priority)
        {
            this.Name = name;
            this.Description = description;
            this.IsDeleted = isDeleted;
            this.IsTask = isTask;
            this.Priority = priority;
            Id = Guid.NewGuid();

            
        }

        public virtual string ToString(bool val)
        {
            
                return $"{Name} - {Description} \n\t";
            
        }
        
    }
}
