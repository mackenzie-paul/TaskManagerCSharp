﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace TaskManager.ViewModel
{
    [Serializable]
    public class MainViewModel : INotifyPropertyChanged
    {
        ObservableCollection<Item> tasksAndAppts;
        public ObservableCollection<Item> TaskAndAppts {
            get
            {
                return tasksAndAppts;
            }
            set
            {
                tasksAndAppts = value;
            }
        }

        private Item selectedItem;
        public event PropertyChangedEventHandler PropertyChanged;

        public MainViewModel()
        {
            TaskAndAppts = new ObservableCollection<Item>();
        }

        

        public Item SelectedItem
        {
            get
            {
                return selectedItem;   
            }
            set
            {
                
                selectedItem = value;
                NotifyPropertyChanged();
            }
        }

        private void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public void Remove()
        {
            TaskAndAppts.Remove(SelectedItem);
        }

    }
}

