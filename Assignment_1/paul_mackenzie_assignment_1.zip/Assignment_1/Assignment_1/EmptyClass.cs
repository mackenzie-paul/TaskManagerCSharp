﻿using System;
namespace Application
{
    public class EmptyClass
    {
        public EmptyClass()
        {
        }
    }
}
