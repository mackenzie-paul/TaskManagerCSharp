﻿//Mackenzie Paul
//Assignment 1
//Due 05/27/21

using System;

namespace Library.TaskManager
{
    public class Task
    {

        //name
        string name;
        public string Name
        {
            get {
                return name;
            }
            set {
                name = value;
            }
        }

        //description
        string description;
        public string Description {
            get
            {
                return description;
            }
            set
            {
                description = value;
            }
        }

        //deadline
        string deadline;
        public string Deadline
        {
            get
            {
                return deadline;
            }
            set
            {
                deadline = value;
            }
        }

        //isComplete
        bool isComplete;
        public bool IsComplete
        {
            get
            {
                return isComplete;
            }
            set
            {
                isComplete = value;
            }
        }

        bool isDeleted;
        public bool IsDeleted
        {
            get
            {
                return isDeleted;
            }
            set
            {
                isDeleted = value;
            }
        }

        public Task(string name, string description, string deadline, bool isComplete, bool isDeleted) {
            Name = name;
            Description = description;
            Deadline = deadline;
            IsComplete = isComplete;
            IsDeleted = isDeleted;
        }


    }
}
