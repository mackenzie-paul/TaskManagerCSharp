﻿//Mackenzie Paul
//Assignment 1
//Due 05/27/21

using System;
using System.Collections.Generic;
using Library.TaskManager;


namespace Assignment_1
{
    class Program
    {

        static void Main(string[] args)
        {
            bool exit = false;

            //list stores all of our tasks
            List<Task> task_list = new List<Task>();

            //while loop that handles user interaction with tasks
            while (!exit)
            {
                //menu
                Console.WriteLine("\n");
                Console.WriteLine("1. Create Task");
                Console.WriteLine("2. List All Tasks");
                Console.WriteLine("3. Delete Task");
                Console.WriteLine("4. Edit Task");
                Console.WriteLine("5. Complete Task");
                Console.WriteLine("6. List Outstanding Tasks");
                Console.WriteLine("7. Exit");
                Console.WriteLine("\n");
                Console.WriteLine("Please select option: ");

                //user choice
                var choice = Console.ReadLine();
                Console.WriteLine("\n");

                if (int.TryParse(choice, out int intChoice))
                {

                    switch (intChoice)
                    {
                        /**************/
                        //1. Creating Task
                        case 1:
                            Console.WriteLine("Creating Task...");
                            Console.WriteLine("Please enter task name: ");
                            var name = Console.ReadLine();
                            Console.WriteLine("Please enter task description: ");
                            var description = Console.ReadLine();
                            Console.WriteLine("Please enter task deadline: ");
                            var deadline = Console.ReadLine();

                            //creating task and adding it to task_list
                            Task task = new Task(name, description, deadline, false, false);
                            task_list.Add(task);
                            break;
                        /**************/
                        //2. Listing Tasks
                        case 2:
                            Console.WriteLine("Listing all tasks...");
                            Console.WriteLine("\n");
                            for (int i = 0; i < task_list.Count; i++)
                            {
                                if (!task_list[i].IsDeleted)
                                {
                                    Console.WriteLine("Task Name: " + task_list[i].Name);
                                    Console.WriteLine("Task Desciption: " + task_list[i].Description);
                                    Console.WriteLine("Task Deadline: " + task_list[i].Deadline);
                                    if (task_list[i].IsComplete)
                                    {
                                        Console.WriteLine("Completed.\n");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Not Completed.\n");
                                    }
                                }
                                
                            }

                            break;
                        /**************/
                        //3. Deleting Task
                        case 3:
                            Console.WriteLine("Deleting Task...");
                            Console.WriteLine("Enter Task Name: ");
                            bool delete_task_found = false;
                            while (!delete_task_found)
                            {
                                string task_name_entry = Console.ReadLine();
                                for (int i = 0; i < task_list.Count; i++)
                                {
                                    if (task_name_entry.Equals(task_list[i].Name) && !task_list[i].IsDeleted)
                                    {
                                        Console.WriteLine("Task Found");
                                        Console.WriteLine("Task Deleted");
                                        task_list[i].IsDeleted = true;
                                        delete_task_found = true;
                                    }
                                }
                                if (!delete_task_found)
                                {
                                    Console.WriteLine("Task Not Found. Please try again.");
                                }
                            }

                                break;
                        /*************/
                        //4. Editing Task
                        case 4:
                            bool task_changed = true;
                            bool task_found = false;
                            int id = -1;
                            Console.WriteLine("Editing Task...");

                            //get task name to change
                            Console.WriteLine("Enter task name: ");
                            while (!task_found)
                            {
                                string task_name_entry = Console.ReadLine();
                                for (int i = 0; i < task_list.Count; i++)
                                {
                                    if (task_name_entry.Equals(task_list[i].Name) && !task_list[i].IsDeleted)
                                    {
                                        Console.WriteLine("\n");
                                        task_found = true;
                                        task_changed = false;
                                        id = i;
                                    }
                                }
                                if (!task_found)
                                {
                                    Console.WriteLine("Task Not Found. Please try again.");
                                }
                            }


                            while (!task_changed)
                            {
                                //item-to-change menu
                                Console.WriteLine("Select value you would like to change.");
                                Console.WriteLine("1. Task Name");
                                Console.WriteLine("2. Task Description");
                                Console.WriteLine("3. Task Deadline");
                                Console.WriteLine("4. Return to Main Menu");

                                var edit_choice = Console.ReadLine();
                                if (int.TryParse(edit_choice, out int edit_choice_val))
                                {
                                    switch (edit_choice_val)
                                    {
                                        case 1:
                                            Console.WriteLine("Editing name...");
                                            Console.WriteLine("Enter New Name: ");
                                            var new_name = Console.ReadLine();
                                            task_list[id].Name = new_name;
                                            break;
                                        case 2:
                                            Console.WriteLine("Editing Description...");
                                            var new_description = Console.ReadLine();
                                            task_list[id].Description = new_description;
                                            break;
                                        case 3:
                                            Console.WriteLine("Editing Deadline...");
                                            var new_deadline = Console.ReadLine();
                                            task_list[id].Deadline = new_deadline;
                                            break;
                                        case 4:
                                            Console.WriteLine("Returning to Main Menu...");
                                            task_changed = true;
                                            break;
                                    }
                                }    
                            }

                            break;
                        /*****************/
                        //Completeing Task
                        case 5:
                            Console.WriteLine("Completing Task...");
                            bool new_task_found = false;
                            Console.WriteLine("Enter task name: ");
                            while (!new_task_found)
                            {
                                string task_name_entry = Console.ReadLine();
                                for (int i = 0; i < task_list.Count; i++)
                                {
                                    if (task_name_entry.Equals(task_list[i].Name) && !task_list[i].IsDeleted)
                                    {
                                        //if task not completed yet
                                        if (!task_list[i].IsComplete)
                                        {
                                            Console.WriteLine("Task Completed");
                                            new_task_found = true;
                                            task_list[i].IsComplete = true;
                                        }
                                        //task already completed
                                        else {
                                            Console.WriteLine("Task Already Complete");
                                        }
                                    }
                                }
                                //no task found
                                if (!new_task_found)
                                {
                                    Console.WriteLine("Task not found. Please try again.");
                                }
                            }
                            
                            break;
                        /**************************/
                        //Listing Outstanding Tasks
                        case 6:
                            Console.WriteLine("Outstanding Tasks");
                            Console.WriteLine("\n");
                            for (int i = 0; i < task_list.Count; i++)
                            {
                                if (!task_list[i].IsComplete && !task_list[i].IsDeleted)
                                {
                                    Console.WriteLine("Task Name: " + task_list[i].Name);
                                    Console.WriteLine("Task Desciption: " + task_list[i].Description);
                                    Console.WriteLine("Task Deadline: " + task_list[i].Deadline + "\n");
                                }
                            }
                            break;
                        /****************/
                        //Exiting Program
                        case 7:
                            Console.WriteLine("Exiting Program.");
                            exit = true;
                            break;
                    }
                }
            }
        }
    }
}
