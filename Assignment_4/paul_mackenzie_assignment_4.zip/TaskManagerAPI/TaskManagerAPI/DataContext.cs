﻿using System;
using System.Collections.Generic;
using Library.TaskManager;

namespace TaskManagerAPI
{
    public class DataContext
    {
        public static List<Item> Task_List = new List<Item> {};
        
    }
}
