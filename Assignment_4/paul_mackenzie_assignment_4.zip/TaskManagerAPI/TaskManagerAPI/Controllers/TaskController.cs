﻿//Mackenzie Paul
//Assignment 4

using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Library.TaskManager;
using System.Linq;

namespace TaskManagerAPI.Controllers
{
    [ApiController]
    [Route("Task")]
    public class TaskController : ControllerBase
    {

        [HttpGet("test")]
        public string Test()
        {
            return "Task Controller Test";
        }

        //returns entire data context list
        [HttpGet("GetAll")]
        public ActionResult<List<Item>> Get()
        {
            return Ok(DataContext.Task_List.Select(t => new Item(t)).ToList());
        }

        //returns tasks
        [HttpGet("GetTask")]
        public ActionResult<List<Task>> GetTasks()
        {
            List<Task> temp = new List<Task>();
            foreach(var task in DataContext.Task_List)
            {
                if (task.IsTask)
                {
                    temp.Add((Task)task);
                }
            }
            return Ok(temp.Select(t => new Task(t)).ToList());
        }

        //adds or updates tasks
        [HttpPost("AddOrUpdateTask")]
        public Task AddOrUpdateTask(Task task)
        {
            //WHY IS TASK BEING MARKED AS FALSE
            Task newTask = null;
            

            if (task.Id == Guid.Empty)
            {
                newTask = new Task(task.Name, task.Description, task.Deadline,
                    task.IsComplete, task.IsDeleted, task.Priority);
                Console.WriteLine(newTask.IsTask);
                newTask.IsTask = true;
                DataContext.Task_List.Add(newTask);
            }
            else
            {
                int index = 0;
                for(int i = 0; i < DataContext.Task_List.Count; i++)
                {
                    if (DataContext.Task_List[i].Id.Equals(task.Id))
                    {
                        index = i;
                        break;
                    }
                }
                newTask = new Task(task.Name, task.Description, task.Deadline,
                    task.IsComplete, task.IsDeleted, task.Priority);
                newTask.IsTask = true;
                newTask.Id = task.Id;
                DataContext.Task_List.RemoveAt(index);
                DataContext.Task_List.Insert(index, newTask);
            }

            return newTask;
        }

        //deletes tasks
        [HttpPost("DeleteTask")]
        public ActionResult<Item> DeleteTask([FromBody] Guid id)
        {
            Task taskToRemove = null;

            
            for (int i = 0; i < DataContext.Task_List.Count; i++)
            {
                
                if (DataContext.Task_List[i].Id.Equals(id))
                {
                    taskToRemove = new Task(DataContext.Task_List[i].Name,
                        DataContext.Task_List[i].Description, DataContext.Task_List[i].Deadline,
                        DataContext.Task_List[i].IsComplete, DataContext.Task_List[i].IsDeleted,
                        DataContext.Task_List[i].Priority);
                    taskToRemove.Id = id;
                    DataContext.Task_List.RemoveAt(i);
                    break;
                }
            }
            
            

            return Ok(new Task(taskToRemove));
        }

        //uses LINQ to find user string and returns items found in a list
        [HttpGet("GetSearchResults")]
        public ActionResult<List<Item>> GetSearchResults(string search_item)
        {
            List<Item> searchResults = new List<Item>();


            var task_item =
                from task in DataContext.Task_List
                where task.IsTask == true && (
                task.Name.Contains(search_item) ||
                task.Description.Contains(search_item))
                select task;

            var appt_item =
                from appt in DataContext.Task_List
                where appt.IsTask == false && (
                appt.Name.Contains(search_item) ||
                appt.Description.Contains(search_item) ||
                appt.Attendees.Contains(search_item))
                select appt;


            foreach (var task in task_item)
            {
                searchResults.Add(task);
            }
            foreach (var appt in appt_item)
            {
                searchResults.Add(appt);
            }

            return Ok(searchResults.Select(t => new Item(t)).ToList());
        }

        //finds and returns incomplete tasks
        [HttpGet("GetIncompleteTasks")]
        public ActionResult<List<Task>> GetIncompleteTasks()
        {

            List<Task> temp = new List<Task>();
            foreach (var task in DataContext.Task_List)
            {
                if (task.IsTask && !task.IsComplete)
                {
                    temp.Add((Task)task);
                }
            }
            return Ok(temp.Select(t => new Task(t)).ToList());
        }
    }

    
}
