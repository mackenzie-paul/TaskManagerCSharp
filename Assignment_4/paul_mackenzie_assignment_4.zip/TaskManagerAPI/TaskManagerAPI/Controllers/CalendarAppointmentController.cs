﻿//Mackenzie Paul
//Assignment 4

using System;
using System.Collections.Generic;
using System.Linq;
using Library.TaskManager;
using Microsoft.AspNetCore.Mvc;

namespace TaskManagerAPI.Controllers
{
    [ApiController]
    [Route("Appointment")]
    public class CalendarAppointmentController : ControllerBase
    {

        [HttpGet("test")]
        public string Test()
        {
            return "Appointment Controller";
        }


        //returns list of appointments
        [HttpGet("GetAppt")]
        public ActionResult<List<Item>> GetAppts()
        {
            List<Item> temp = new List<Item>();
            foreach (var task in DataContext.Task_List)
            {
                if (!task.IsTask)
                {
                    temp.Add(task);
                }
            }
            return Ok(temp.Select(t => new Item(t)).ToList());
        }

        //adds or updates appointments
        [HttpPost("AddOrUpdateAppt")]
        public CalendarAppointments AddOrUpdateAppt(CalendarAppointments appt)
        {

            CalendarAppointments newAppt = null;
            

            if (appt.Id == Guid.Empty)
            {
                newAppt = new CalendarAppointments(appt.Name, appt.Description, appt.Start, appt.Stop,
                   appt.Attendees, appt.IsDeleted, appt.Priority);

                DataContext.Task_List.Add(newAppt);
            }
            else
            {
                int index = 0;
                for (int i = 0; i < DataContext.Task_List.Count; i++)
                {
                    if (DataContext.Task_List[i].Id.Equals(appt.Id))
                    {
                        index = i;
                        break;
                    }
                }
                newAppt = new CalendarAppointments(appt.Name, appt.Description, appt.Start,
                    appt.Stop, appt.Attendees, appt.IsDeleted, appt.Priority);
                newAppt.Id = appt.Id;
                DataContext.Task_List.RemoveAt(index);
                DataContext.Task_List.Insert(index, newAppt);
            }


            return newAppt;
        }

        //deletes appointment
        [HttpPost("DeleteAppt")]
        public ActionResult<Item> DeleteAppt([FromBody] Guid id)
        {

            CalendarAppointments apptToRemove = null;
         
            for (int i = 0; i < DataContext.Task_List.Count; i++)
            {

                if (DataContext.Task_List[i].Id.Equals(id))
                {
                    apptToRemove = new CalendarAppointments(DataContext.Task_List[i].Name,
                        DataContext.Task_List[i].Description, DataContext.Task_List[i].Start,
                        DataContext.Task_List[i].Stop, DataContext.Task_List[i].Attendees,
                        DataContext.Task_List[i].IsDeleted,
                        DataContext.Task_List[i].Priority);
                    apptToRemove.Id = id;
                    DataContext.Task_List.RemoveAt(i);
                    break;
                }
            }

            

            return Ok(new CalendarAppointments(apptToRemove));

            
        }
    }
}

