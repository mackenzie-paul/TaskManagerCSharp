﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Library.TaskManager;
using Newtonsoft.Json;

namespace TaskManager
{
    [Serializable]
    public class MainViewModel : INotifyPropertyChanged
    {
        ObservableCollection<Item> tasksAndAppts;
        public ObservableCollection<Item> TaskAndAppts {
            get
            {
                return tasksAndAppts;
            }
            set
            {
                tasksAndAppts = value;
            }
        }

        private Item selectedItem;
        public event PropertyChangedEventHandler PropertyChanged;

        public MainViewModel()
        {
            TaskAndAppts = new ObservableCollection<Item>();
        }

        

        public Item SelectedItem
        {
            get
            {
                return selectedItem;   
            }
            set
            {
                
                selectedItem = value;
                
                NotifyPropertyChanged();
            }
        }

        private void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public async void Remove()
        {
            if (SelectedItem.IsTask)
            {
                
                var thisItem = SelectedItem;
                thisItem = JsonConvert.DeserializeObject<Task>
                    (await new WebRequestHandler().Post("http://10.0.2.2:5000/Task/DeleteTask",
                    thisItem.Id));
            }
            else
            {
                var thisAppt = SelectedItem;
                thisAppt = JsonConvert.DeserializeObject<CalendarAppointments>
                    (await new WebRequestHandler().Post("http://10.0.2.2:5000/Appointment/DeleteAppt",
                    thisAppt.Id));
            }
            TaskAndAppts.Remove(SelectedItem);
        }

    }
}

