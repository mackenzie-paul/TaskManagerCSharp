﻿//Mackenzie Paul
//Assignment 4

using System;
using System.Collections.Generic;
using TaskManager.Pages;
using Library.TaskManager;
using Xamarin.Forms;
using Newtonsoft.Json;
using System.Net.Http;
using Org.Apache.Http.Client;
using Android.Security;
using Xamarin.Forms.Internals;


//There is a bug when loading list and deleting, was unable to identify the source in a timely 
//manner and will address in assignment 5
//IMPORTANT: I am currently running this application on a 2012 MacBook Pro and am
//unable to test the iOS application because my system will not update anymore. I cannot access the
//version of XCode that is required of me to run the iOS simulator, so I have no idea if the iOS app runs.
namespace TaskManager
{
    public partial class MainPage : ContentPage
    {
        private ListView list;

        public MainPage()
        {
            InitializeComponent();
            BindingContext = new MainViewModel();
            var handler = new WebRequestHandler();
            var sample = handler.Get("http://10.0.2.2:5000/Task/GetAll").Result;
            var tasks = JsonConvert.DeserializeObject <List<Item>>(sample);

            
            foreach(var task in tasks)
            {
                
                Console.WriteLine(task.Preview);
              
                (BindingContext as MainViewModel).TaskAndAppts.Add(task);
            }

            list = (task_listview);
        }


        //when item in listview tapped, display with item info appears
        //user given options to update and delete
        private async void Item_Tapped(object sender, EventArgs e)
        {
            string title = "";
            if((BindingContext as MainViewModel).SelectedItem.Priority.Equals("Medium"))
            {
                title += "! ";
            }else if ((BindingContext as MainViewModel).SelectedItem.Priority.Equals("High"))
            {
                title += "!! ";
            }

            title += (BindingContext as MainViewModel).SelectedItem.Name;

            
            string description = Printout((BindingContext as MainViewModel).SelectedItem);
            bool answer = await DisplayAlert(title, description, "Update/Delete", "Cancel");
            if (answer)
            {
                bool update = await DisplayAlert("Update or Delete", "Please select whether you wish to update or delete.",
                    "Update", "Delete");
                if (update)
                {
                    if ((BindingContext as MainViewModel).SelectedItem.IsTask)
                    {
                        var edit_task_diag = new UpdateTaskForm((BindingContext as MainViewModel).TaskAndAppts,
                                    (BindingContext as MainViewModel).SelectedItem);
                        _ = Navigation.PushModalAsync(edit_task_diag);
                    }
                    else
                    {
                        var edit_appt_diag = new UpdateApptForm((BindingContext as MainViewModel).TaskAndAppts,
                                    (BindingContext as MainViewModel).SelectedItem);
                        _ = Navigation.PushModalAsync(edit_appt_diag);
                    }
                }
                else
                {
                    bool delete = await DisplayAlert("Delete", "Are you sure you wish to delete this.",
                    "Yes", "No");
                    if (delete)
                    {
                        (BindingContext as MainViewModel).Remove();
                    }
                }
            }
            else
            {
                Console.WriteLine("Cancel");
            }
        }


        
        private async void Search_Clicked(object sender, EventArgs e)
        {


            //user string sent to api, returns items found with string
            SearchBar searchBar = (SearchBar)sender;
            string userInput = searchBar.Text;
            var handler = new WebRequestHandler();
            var sample = handler.Get("http://10.0.2.2:5000/Task/GetSearchResults?search_item=" + userInput).Result;
            var tasks = JsonConvert.DeserializeObject<List<Item>>(sample);

            List<string> printout = new List<string>();
            foreach (var val in tasks)
            {
                printout.Add(val.Name + "\n" + Printout(val));
            }

            string[] tAndA = printout.ToArray();
            string action = await DisplayActionSheet("Tasks and Appointments Found:", "Cancel", null, tAndA);
        }

        private async void Options_Clicked(object sender, EventArgs e)
        {
            var handler = new WebRequestHandler();
            string[] buttons = {"Create Task", "Create Appointment", "List Incomplete Tasks",
                "Sort by Priority","Display Tasks", "Display Appointments", "Complete Task",
                "Save List", "Load List"};
            string action = await DisplayActionSheet("Select one: ", "Cancel", null, buttons);
            
            switch (action)
            {
                
                case "Create Task":
                    var task_diag = new CreateTaskForm((BindingContext as MainViewModel).TaskAndAppts);
                    _ = Navigation.PushModalAsync(task_diag);
                    break;
                case "Create Appointment":
                    
                    var appt_diag = new CreateApptForm((BindingContext as MainViewModel).TaskAndAppts);
                    _ = Navigation.PushModalAsync(appt_diag);
                    break;

                case "List Incomplete Tasks":
                    
                    var sample = new WebRequestHandler().Get("http://10.0.2.2:5000/Task/GetIncompleteTasks").Result;
                    var tasks = JsonConvert.DeserializeObject<List<Item>>(sample);

                    List<string> printout = new List<string>();
                    foreach (var val in tasks)
                    {
                        printout.Add(val.Name + "\n" + Printout(val));
                    }

                    string[] tAndA = printout.ToArray();
                    string incomplete_action = await DisplayActionSheet("Tasks and Appointments Found:", "Cancel", null, tAndA);

                    break;

                case "Sort by Priority":
                    // NEED TO SORT LIST BY PRIORITY
                    // change actual list this is being printed - not saved list (if saved)

                    List<Item> temp_list = new List<Item>();
                    foreach (var item in (BindingContext as MainViewModel).TaskAndAppts)
                    {
                        if (item.Priority.Equals("High"))
                        {
                            temp_list.Add(item);
                        }
                    }

                    foreach (var item in (BindingContext as MainViewModel).TaskAndAppts)
                    {
                        if (item.Priority.Equals("Medium"))
                        {
                            temp_list.Add(item);
                        }
                    }

                    foreach (var item in (BindingContext as MainViewModel).TaskAndAppts)
                    {
                        if (item.Priority.Equals("Low"))
                        {
                            temp_list.Add(item);
                        }
                    }

                    (BindingContext as MainViewModel).TaskAndAppts.Clear();
                    foreach (var item in temp_list)
                    {
                        (BindingContext as MainViewModel).TaskAndAppts.Add(item);
                    }
                    list.ItemsSource = (BindingContext as MainViewModel).TaskAndAppts;
                    break;


                case "Display Tasks":


                    var task_sample = handler.Get("http://10.0.2.2:5000/Task/GetTask").Result;
                    var only_tasks = JsonConvert.DeserializeObject<List<Item>>(task_sample);
                    List<string> task_printout = new List<string>();
                    foreach (var val in only_tasks)
                    {
                        task_printout.Add(val.Name + "\n" + Printout(val));
                    }

                    string[] task_array = task_printout.ToArray();
                    string task_action = await DisplayActionSheet("Tasks and Appointments Found:", "Cancel", null, task_array);
                    
                    
                    break;

                case "Display Appointments":
                    
                    var appt_sample = handler.Get("http://10.0.2.2:5000/Appointment/GetAppt").Result;
                    var only_appts = JsonConvert.DeserializeObject<List<Item>>(appt_sample);
                    List<string> appt_printout = new List<string>();
                    foreach (var val in only_appts)
                    {
                        appt_printout.Add(val.Name + "\n" + Printout(val));
                    }

                    string[] appt_array = appt_printout.ToArray();
                    string appt_action = await DisplayActionSheet("Tasks and Appointments Found:", "Cancel", null, appt_array);

                    break;
                case "Complete Task":
                    if ((BindingContext as MainViewModel).SelectedItem != null &&
                        (BindingContext as MainViewModel).SelectedItem.IsTask)
                    {
                        (BindingContext as MainViewModel).SelectedItem.IsComplete = true;
                        Task thisTask = JsonConvert.DeserializeObject<Task>(await new WebRequestHandler().
                            Post("http://10.0.2.2:5000/Task/AddOrUpdateTask", (BindingContext as MainViewModel).SelectedItem));
                        (BindingContext as MainViewModel).TaskAndAppts.Clear();
                        
                        var allList = new WebRequestHandler().Get("http://10.0.2.2:5000/Task/GetAll").Result;
                        var updatedList = JsonConvert.DeserializeObject<List<Item>>(allList);

                        foreach(var item in updatedList)
                        {
                            (BindingContext as MainViewModel).TaskAndAppts.Add(item);

                        }
                    }
                    else
                    {
                        _ = DisplayAlert("Task Not Selected", "Please select a task to complete.", "Cancel");
                    }
                    break;
                case "Save List":
                    //ask user for the save name
                    //save task_list to user's file
                    var save_list_diag = new SaveTaskListForm((BindingContext as MainViewModel).TaskAndAppts);
                    _ = Navigation.PushModalAsync(save_list_diag);
                    break;
                case "Load List":
                    //ask for a name to open task_list
                    //open saved task_list
                    var load_list_diag = new LoadTaskListForm((BindingContext as MainViewModel).TaskAndAppts);
                    _ = Navigation.PushModalAsync(load_list_diag);
                    break;
            }
            
            
        }

        private string Printout(Item item)
        {
            string description = "";
            
            if (item.IsTask)
            {
                description += "(Task)\n";
                description += "Description: " + item.Description;
                description += "\nDeadline: " + item.Deadline.ToString("MMM dd, yyyy");
                if (item.IsComplete)
                {
                    description += "\nComplete";
                }
                else
                {
                    description += "\nINCOMPLETE";
                }
            }
            else
            {
                description += "(Appointment)\n";
                description += "Description: " + item.Description;
                description += "\nStart Date: " + item.Start.ToString("MMM dd, yyyy");
                description += "\nStop Date: " + item.Stop.ToString("MMM dd, yyyy");
                description += "\nAttendees:\n ";

                foreach (var attendee in item.Attendees)
                {
                    description += attendee + "\n ";
                }
            }


            return description;
        }
    }
}