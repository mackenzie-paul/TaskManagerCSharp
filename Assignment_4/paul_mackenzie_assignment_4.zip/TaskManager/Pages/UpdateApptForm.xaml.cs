﻿using System;
using System.Collections.Generic;
using Library.TaskManager;
using Newtonsoft.Json;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TaskManager.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class UpdateApptForm : ContentPage
    {


        private ICollection<Item> tasksAndAppts;
        List<string> attendees;
        public UpdateApptForm(ICollection<Item> tasksAndAppts, Item updateItem)
        {
            InitializeComponent();
            this.tasksAndAppts = tasksAndAppts;
            attendees = updateItem.Attendees;
            BindingContext = updateItem;
            if (updateItem.Priority.Equals("Low"))
            {
                low_priority.IsChecked = true;
            }
            else if(updateItem.Priority.Equals("Medium"))
            {

                med_priority.IsChecked = true;
            }
            else
            {
                high_priority.IsChecked = true;
            }
        }

        public void Back_Clicked(object sender, EventArgs e)
        {
            Navigation.PopModalAsync();
        }

        public async void Update_Clicked(object sender, EventArgs e)
        {

            bool all_fields_pass = true;

            //checks that all fields have entries
            string appt_name_string = appt_name_entry.Text;
            if (appt_name_string.Equals(""))
            {
                appt_name.TextColor = Color.Red;
                all_fields_pass = false;
            }
            else
            {
                appt_name.TextColor = Color.Gray;
            }

            string appt_desc_string = appt_desc_entry.Text;
            if (appt_desc_string.Equals(""))
            {
                appt_desc.TextColor = Color.Red;
                all_fields_pass = false;
            }
            else
            {
                appt_desc.TextColor = Color.Gray;
            }

            

            if (all_fields_pass)
            {
                tasksAndAppts.Remove(BindingContext as Item);

                //checks priority
                if (low_priority.IsChecked)
                {
                    (BindingContext as Item).Priority = "Low";
                }
                else if (med_priority.IsChecked)
                {
                    (BindingContext as Item).Priority = "Medium";
                }
                else if (high_priority.IsChecked)
                {
                    (BindingContext as Item).Priority = "High";
                }

                //replaces old object
                var thisAppt = BindingContext as Item;
                thisAppt.IsTask = false;
                thisAppt = JsonConvert.DeserializeObject<CalendarAppointments>(await new WebRequestHandler().Post(
                    "http://10.0.2.2:5000/Appointment/AddOrUpdateAppt", thisAppt));
                tasksAndAppts.Clear();
                var handler = new WebRequestHandler();
                var sample = handler.Get("http://10.0.2.2:5000/Task/GetAll").Result;
                var appts = JsonConvert.DeserializeObject<List<Item>>(sample);

                foreach (var appt in appts)
                {

                    Console.WriteLine(appt.Preview);

                    tasksAndAppts.Add(appt);
                }
                _ = Navigation.PopModalAsync();
            }
            else
            {
                _ = DisplayAlert("Missing Information", "Please check all fields", "Cancel");
            }
        }

        public void Add_Attendee(object sender, EventArgs e)

        {

            var attendee = attendee_entry.Text;
            attendees.Add(attendee);
        }
    }
}
