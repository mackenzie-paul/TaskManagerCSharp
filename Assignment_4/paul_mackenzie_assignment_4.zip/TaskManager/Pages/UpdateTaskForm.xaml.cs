﻿using System;
using System.Collections.Generic;
using Library.TaskManager;
using Newtonsoft.Json;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TaskManager.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class UpdateTaskForm : ContentPage
    {


        private ICollection<Item> tasksAndAppts;
        public UpdateTaskForm(ICollection<Item> tasksAndAppts, Item updateItem)
        {
            InitializeComponent();
            this.tasksAndAppts = tasksAndAppts;
            BindingContext = updateItem;
            if (updateItem.Priority.Equals("Low"))
            {
                low_priority.IsChecked = true;
            }
            else if (updateItem.Priority.Equals("Medium"))
            {

                med_priority.IsChecked = true;
            }
            else
            {
                high_priority.IsChecked = true;
            }
        }

        public void Back_Clicked(object sender, EventArgs e)
        {
            Navigation.PopModalAsync();
        }

        public async void Update_Clicked(object sender, EventArgs e)
        {
            bool all_fields_pass = true;

            //checks that all fields have entries
            string task_name_string = task_name_entry.Text;
            if (task_name_string.Equals(""))
            {
                task_name.TextColor = Color.Red;
                all_fields_pass = false;
            }
            else
            {
                task_name.TextColor = Color.Gray;
            }

            string task_desc_string = task_desc_entry.Text;
            if (task_desc_string.Equals(""))
            {
                task_desc.TextColor = Color.Red;
                all_fields_pass = false;
            }
            else
            {
                task_desc.TextColor = Color.Gray;
            }

            

            if (all_fields_pass)
            {
                tasksAndAppts.Remove(BindingContext as Item);
                
                //checks priority
                if (low_priority.IsChecked)
                {
                    (BindingContext as Item).Priority = "Low";
                }
                else if (med_priority.IsChecked)
                {
                    (BindingContext as Item).Priority = "Medium";
                }
                else if (high_priority.IsChecked)
                {
                    (BindingContext as Item).Priority = "High";
                }

                //replaces old object
                var thisTask = BindingContext as Item;
                thisTask.IsTask = true;
                thisTask = JsonConvert.DeserializeObject<Task>(await new WebRequestHandler().Post(
                    "http://10.0.2.2:5000/Task/AddOrUpdateTask", thisTask));
                tasksAndAppts.Clear();
                var handler = new WebRequestHandler();
                var sample = handler.Get("http://10.0.2.2:5000/Task/GetAll").Result;
                var tasks = JsonConvert.DeserializeObject<List<Item>>(sample);


                foreach (var task in tasks)
                {

                    Console.WriteLine(task.Preview);

                    tasksAndAppts.Add(task);
                }
                _ = Navigation.PopModalAsync();
            }
            else
            {
                _ = DisplayAlert("Missing Information", "Pleas check all fields.", "Cancel");
            }
        }
    }
}
